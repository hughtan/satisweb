<?php

class ClassLoaderTest_ClassA
{

}