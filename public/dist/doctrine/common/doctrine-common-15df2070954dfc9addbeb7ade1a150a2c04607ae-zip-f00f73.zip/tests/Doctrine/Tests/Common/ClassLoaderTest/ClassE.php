<?php

namespace ClassLoaderTest;

class ClassE {}
