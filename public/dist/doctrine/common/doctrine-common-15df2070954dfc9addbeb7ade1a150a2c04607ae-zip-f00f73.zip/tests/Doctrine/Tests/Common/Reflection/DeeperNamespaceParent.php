<?php

namespace Doctrine\Tests\Common\Reflection;

class SameNamespaceParent extends Dummies\NoParent
{
}
