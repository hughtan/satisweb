<?php

namespace Doctrine\Tests\Common\Reflection;

use Doctrine\Tests\Common\Reflection\Dummies\NoParent as Test;

class UseParent extends Test
{
}
