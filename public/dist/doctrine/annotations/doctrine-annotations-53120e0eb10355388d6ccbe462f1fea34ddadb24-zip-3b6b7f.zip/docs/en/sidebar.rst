.. toctree::
    :depth: 3

    index
    annotations
    custom
