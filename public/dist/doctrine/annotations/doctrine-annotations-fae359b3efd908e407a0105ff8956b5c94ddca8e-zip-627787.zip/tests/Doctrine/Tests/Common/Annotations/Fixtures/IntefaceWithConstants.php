<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures;

interface IntefaceWithConstants
{

    const SOME_VALUE = 'IntefaceWithConstants.SOME_VALUE';
    const SOME_KEY   = 'IntefaceWithConstants.SOME_KEY';
}