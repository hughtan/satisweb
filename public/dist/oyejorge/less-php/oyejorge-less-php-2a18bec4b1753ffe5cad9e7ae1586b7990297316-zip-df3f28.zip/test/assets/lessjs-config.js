
	less = {
		env: "development",
		logLevel: 2,
		async: false,
		fileAsync: false,
		//poll: 1000,
		functions: {},
		//dumpLineNumbers: "comments",
		//relativeUrls: false,
		//rootpath: ":/a.com/"
	};