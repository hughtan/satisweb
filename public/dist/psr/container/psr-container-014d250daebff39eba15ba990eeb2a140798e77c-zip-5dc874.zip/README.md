# PSR Container

This repository holds all interfaces/classes/traits related to [PSR-11](https://github.com/php-fig/fig-standards/blob/master/accepted/PSR-11-container.md).

Note that this is not a container implementation of its own. See the specification for more details.
