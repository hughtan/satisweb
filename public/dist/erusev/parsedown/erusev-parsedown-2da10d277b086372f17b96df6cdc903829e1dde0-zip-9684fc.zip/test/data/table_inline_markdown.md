| _header_ 1   | header 2     |
| ------------ | ------------ |
| _cell_ 1.1   | ~~cell~~ 1.2 |
| `cell` 2.1   | cell 2.2     |