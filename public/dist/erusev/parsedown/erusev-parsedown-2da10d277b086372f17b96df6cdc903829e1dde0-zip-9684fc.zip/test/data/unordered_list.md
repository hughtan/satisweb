- li
- li

mixed markers:

* li
+ li
- li