<hr />

attributes:

<hr style="background: #9bd;" />

...