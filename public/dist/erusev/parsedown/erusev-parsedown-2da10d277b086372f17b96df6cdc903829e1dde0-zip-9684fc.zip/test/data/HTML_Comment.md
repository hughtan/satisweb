<!-- single line -->

paragraph

<!-- 
  multiline -->

paragraph