[double quotes] and [single quotes] and [parentheses]

[double quotes]: http://example.com "example title"
[single quotes]: http://example.com 'example title'
[parentheses]: http://example.com (example title)
[invalid title]: http://example.com example title