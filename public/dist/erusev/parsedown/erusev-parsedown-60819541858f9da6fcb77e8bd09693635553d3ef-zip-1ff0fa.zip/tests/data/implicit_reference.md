an [implicit] reference link

[implicit]: http://example.com

an [implicit][] reference link with an empty link definition

an [explicit][example] reference link with a title

[example]: http://example.com "Example"