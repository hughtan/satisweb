Headings:

<h2 id="overview">Overview</h2>
blah
<H2 id="block">Block Elements</H2>
blah
<h3 id="span">
      Span Elements
</h3>
blah

Hr's:

<hr>
blah

<hr/>
blah

<hr />
blah

<hr>   
blah

<hr/>  
blah

<hr /> 
blah

<hr class="foo" id="bar" />
blah

<hr class="foo" id="bar"/>
blah

<hr class="foo" id="bar" >
blah
