<div>_content_</div>

sparse:

<div>
_content_
</div>