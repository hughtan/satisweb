<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

trait FinalMethod2Trait
{
    public function finalMethod2()
    {
    }
}
