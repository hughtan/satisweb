Symfony Polyfill / Iconv
========================

This component provides a native PHP implementation of the
[php.net/iconv](http://php.net/iconv) functions
(short of [`ob_iconv_handler`](http://php.net/manual/en/function.ob-iconv-handler.php)).

More information can be found in the
[main Polyfill README](https://github.com/symfony/polyfill/blob/master/README.md).

License
=======

This library is released under the [MIT license](LICENSE).
