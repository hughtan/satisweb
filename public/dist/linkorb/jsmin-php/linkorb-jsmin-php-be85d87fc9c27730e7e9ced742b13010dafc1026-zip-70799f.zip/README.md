# jsmin-php

Unofficial repo containing a composer enabled jsmin-php

Please check the composer.json for original authors and credits.
