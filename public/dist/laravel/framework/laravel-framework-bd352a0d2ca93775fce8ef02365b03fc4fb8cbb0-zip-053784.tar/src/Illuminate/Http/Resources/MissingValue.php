<?php

namespace Illuminate\Http\Resources;

class MissingValue
{
    //
}
