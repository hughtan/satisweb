@extends('errors::layout')

@section('title', 'Error')

@section('message', 'Too many requests.')
