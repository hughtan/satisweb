Installation
============

Install `Composer`_ and run the following command to get the latest version:

.. code-block:: bash

    composer require "twig/twig:^2.0"

.. _`Composer`: https://getcomposer.org/download/
