/*
 * This is a bundle file, you can compile this in two ways:
 * (1) Using your favorite JS combiner
 * (2) Using CLI command:
 *   php artisan october:util compile assets
 *
 * @see build-min.js
 *
 * Current Ace build v1.2.3 using "src-noconflict"
 * https://github.com/ajaxorg/ace-builds/
 *

=require ../vendor/emmet/emmet.js
=require ../vendor/ace/ace.js
=require ../vendor/ace/ext-emmet.js
=require ../vendor/ace/ext-language_tools.js
=require ../vendor/ace/mode-php.js
=require ../vendor/ace/mode-twig.js
=require ../vendor/ace/mode-markdown.js
=require ../vendor/ace/mode-plain_text.js
=require ../vendor/ace/mode-html.js
=require ../vendor/ace/mode-less.js
=require ../vendor/ace/mode-css.js
=require ../vendor/ace/mode-scss.js
=require ../vendor/ace/mode-sass.js
=require ../vendor/ace/mode-yaml.js
=require ../vendor/ace/mode-javascript.js

=require codeeditor.js

*/
