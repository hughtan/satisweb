<?php namespace Cms\Classes;

/**
 * Parent class for PHP classes created for page PHP sections.
 *
 * @package october\cms
 * @author Alexey Bobkov, Samuel Georges
 */
class PageCode extends CodeBase
{
}
