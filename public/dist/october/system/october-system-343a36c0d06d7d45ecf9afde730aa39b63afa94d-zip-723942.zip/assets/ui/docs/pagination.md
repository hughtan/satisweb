# Pagination

Pagination

# Example

<div class="control-pagination">
    <span class="page-iteration">Displayed records: 1-5 of 20</span>
    <a href="#" class="page-back" title="Previous page"></a><a href="#" class="page-next" title="Next page"></a>
</div>