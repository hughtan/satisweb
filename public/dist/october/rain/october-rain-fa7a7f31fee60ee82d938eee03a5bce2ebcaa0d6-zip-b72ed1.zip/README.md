October Rain
=======

This repository contains the core library of October CMS. If you want to build a website using October, visit the main [October repository](http://github.com/octobercms/october).
