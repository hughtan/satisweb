<?php

use October\Rain\Support\Str;

class StrTest extends TestCase
{
    public function testNothing()
    {
    }
}