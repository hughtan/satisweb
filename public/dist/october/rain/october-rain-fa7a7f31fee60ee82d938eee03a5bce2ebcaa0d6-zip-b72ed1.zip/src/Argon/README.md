## Rain Argon

Argon is a simple PHP API extension for DateTime, and is the cousin of Carbon. The goal of this library is to create a solution for displaying localized dates and introducing more robust features.

This library acts as an umbrella for the Date library:
https://github.com/jenssegers/date