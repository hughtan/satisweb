<?php namespace October\Rain\Support;

use Illuminate\Support\ServiceProvider as ServiceProviderBase;

abstract class ServiceProvider extends ServiceProviderBase
{
}
