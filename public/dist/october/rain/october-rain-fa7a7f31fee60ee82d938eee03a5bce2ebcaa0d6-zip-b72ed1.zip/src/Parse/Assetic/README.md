# Rain Assetic Resources

These libraries are useful when parsing assets with the Assetic combiner.
