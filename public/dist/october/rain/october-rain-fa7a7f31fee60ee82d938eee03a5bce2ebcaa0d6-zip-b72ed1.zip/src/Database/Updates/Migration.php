<?php namespace October\Rain\Database\Updates;

use Illuminate\Database\Migrations\Migration as MigrationBase;

class Migration extends MigrationBase
{
}