<?php namespace October\Rain\Database\Attach;

use Exception;

/**
 * File Exception
 *
 * @package october\database
 * @author Alexey Bobkov, Samuel Georges
 */
class FileException extends Exception
{

}