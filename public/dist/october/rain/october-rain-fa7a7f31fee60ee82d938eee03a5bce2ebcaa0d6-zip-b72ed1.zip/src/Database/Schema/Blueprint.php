<?php namespace October\Rain\Database\Schema;

use Illuminate\Database\Schema\Blueprint as BaseBlueprint;

/**
 * Proxy class
 */
class Blueprint extends BaseBlueprint
{
}
