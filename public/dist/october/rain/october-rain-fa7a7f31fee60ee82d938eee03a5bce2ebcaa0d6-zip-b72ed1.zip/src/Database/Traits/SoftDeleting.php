<?php namespace October\Rain\Database\Traits;

/**
 * @deprecated use SoftDelete trait instead.
 */
trait SoftDeleting
{
    use SoftDelete;
}
