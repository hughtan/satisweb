<?php namespace October\Rain\Database\Updates;

use Illuminate\Database\Seeder as SeederBase;

class Seeder extends SeederBase
{
}
