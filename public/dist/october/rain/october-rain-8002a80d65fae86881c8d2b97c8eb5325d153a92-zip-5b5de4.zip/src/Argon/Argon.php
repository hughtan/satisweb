<?php namespace October\Rain\Argon;

use Jenssegers\Date\Date as DateBase;

/**
 * Umbrella class.
 */
class Argon extends DateBase
{
}
