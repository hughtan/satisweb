<?php namespace October\Rain\Halcyon;

use October\Rain\Support\Collection as CollectionBase;

/**
 * This class represents a collection of Halcyon models.
 *
 * @package october\halcyon
 * @author Alexey Bobkov, Samuel Georges
 */
class Collection extends CollectionBase
{
}
