<?php
return [
    'test' => [
        'pagination' => 'Displayed records: :from-:to of :total',
        'hello_october' => 'Hello October!'
    ],
];
