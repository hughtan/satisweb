<?php namespace October\Rain\Halcyon;

/**
 * Provides a simple request-level cache for models.
 *
 * @package october\halcyon
 * @author Alexey Bobkov, Samuel Georges
 */
class MemoryCache
{
    public static $cache = [];
}
