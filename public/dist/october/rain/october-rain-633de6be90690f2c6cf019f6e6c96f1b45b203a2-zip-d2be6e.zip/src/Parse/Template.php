<?php namespace October\Rain\Parse;

/**
 * @deprecated Delete this class if year >= 2017
 */
class Template extends Bracket
{
}