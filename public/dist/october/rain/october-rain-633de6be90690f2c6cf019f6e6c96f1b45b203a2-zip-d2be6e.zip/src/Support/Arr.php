<?php namespace October\Rain\Support;

use Illuminate\Support\Arr as ArrHelper;

/**
 * Array helper
 *
 * @package october\support
 * @author Alexey Bobkov, Samuel Georges
 */
class Arr extends ArrHelper
{

}