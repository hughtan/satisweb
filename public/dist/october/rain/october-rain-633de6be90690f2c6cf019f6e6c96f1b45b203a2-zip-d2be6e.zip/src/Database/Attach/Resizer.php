<?php namespace October\Rain\Database\Attach;

use File as FileHelper;
use Symfony\Component\HttpFoundation\File\File as FileObj;
use Exception;

/**
 * Image resizer
 *
 * Usage:
 *      Resizer::open(mixed $file)
 *          ->resize(int $width , int $height, string 'exact, portrait, landscape, auto or crop')
 *          ->save(string 'path/to/file.jpg', int $quality);
 *
 *      // Resize and save an image.
 *      Resizer::open(Input::file('field_name'))
 *          ->resize(800, 600, 'crop')
 *          ->save('path/to/file.jpg', 100);
 *
 *      // Recompress an image.
 *      Resizer::open('path/to/image.jpg')
 *          ->save('path/to/new_image.jpg', 60);
 *
 * @package october\database
 * @author Alexey Bobkov, Samuel Georges
 */
class Resizer
{
    /**
     * @var Resource The symfony uploaded file object.
     */
    protected $file;

    /**
     * @var Resource The extension of the uploaded file.
     */
    protected $extension;

    /**
     * @var Resource The image (on disk) that's being resized.
     */
    protected $image;

    /**
     * @var Resource The cached, original image.
     */
    protected $originalImage;

    /**
     * @var int Original width of the image being resized.
     */
    protected $width;
    
    /**
     * @var int Original height of the image being resized.
     */
    protected $height;

    /**
     * @var array Array of options used for resizing.
     */
    protected $options = [];

    /**
     * Instantiates the Resizer and receives the path to an image we're working with
     * @param mixed $file The file array provided by Laravel's Input::file('field_name') or a path to a file
     */
    function __construct($file)
    {
        if (!extension_loaded('gd')) {
            echo 'GD PHP library required.'.PHP_EOL;
            exit(1);
        }

        if (is_string($file)) {
            $file = new FileObj($file);
        }

        // Get the file extension
        $this->extension = $file->guessExtension();

        // Open up the file
        $this->image = $this->originalImage = $this->openImage($file);

        // Get width and height of our image
        $this->width  = imagesx($this->image);
        $this->height = imagesy($this->image);

        // Set default options
        $this->setOptions([]);
    }

    /**
     * Static call, Laravel style.
     * Returns a new Resizer object, allowing for chainable calls
     * @param  mixed $file The file array provided by Laravel's Input::file('field_name') or a path to a file
     * @return Resizer
     */
    public static function open($file)
    {
        return new Resizer($file);
    }

    /**
     * Resets the image back to the original.
     * @return self
     */
    public function reset()
    {
        $this->image = $this->originalImage;

        return $this;
    }

    /**
     * Sets resizer options. Available options are:
     *  - mode: Either exact, portrait, landscape, auto or crop.
     *  - offset: The offset of the crop = [ left, top ]
     *  - sharpen: Sharpen image, from 0 - 100 (default: 0)
     *  - quality: Image quality, from 0 - 100 (default: 95)
     * @return self
     */
    public function setOptions($options)
    {
        $this->options = array_merge($options, [
            'mode'    => 'auto',
            'offset'  => [],
            'sharpen' => 0,
            'quality' => 95
        ]);

        return $this;
    }

    /**
     * Sets an individual resizer option.
     * @return self
     */
    protected function setOption($option, $value)
    {
        $this->options[$option] = $value;

        return $this;
    }

    /**
     * Gets an individual resizer option.
     * @return self
     */
    protected function getOption($option)
    {
        return array_get($this->options, $option);
    }

    /**
     * Resizes and/or crops an image
     * @param int $newWidth The width of the image
     * @param int $newHeight The height of the image
     * @param array $options A set of resizing options, supported values:
     * @return self
     */
    public function resize($newWidth, $newHeight, $options = [])
    {
        $this->setOptions($options);

        /*
         * Sanitize input
         */
        $newWidth = (int) $newWidth;
        $newHeight = (int) $newHeight;

        if (!$newWidth && !$newHeight) {
            $newWidth = $this->width;
            $newHeight = $this->height;
        }
        elseif (!$newWidth) {
            $newWidth = $this->getSizeByFixedHeight($newHeight);
        }
        elseif (!$newHeight) {
            $newHeight = $this->getSizeByFixedWidth($newWidth);
        }

        // Get optimal width and height - based on supplied mode.
        list($optimalWidth, $optimalHeight) = $this->getDimensions($newWidth, $newHeight);

        // Resample - create image canvas of x, y size
        $imageResized = imagecreatetruecolor($optimalWidth, $optimalHeight);

        // Retain transparency for PNG and GIF files
        imagecolortransparent($imageResized, imagecolorallocatealpha($imageResized, 0, 0, 0, 127));
        imagealphablending($imageResized, false);
        imagesavealpha($imageResized, true);

        // Create the new image
        imagecopyresampled($imageResized, $this->image, 0, 0, 0, 0, $optimalWidth, $optimalHeight, $this->width, $this->height);

        $this->image = $imageResized;

        /*
         * Apply sharpness
         */
        if ($sharpen = $this->getOption('sharpen')) {
            $this->sharpen($sharpen);
        }

        /*
         * If mode is crop: find center and use for the cropping.
         */
        if ($this->getOption('mode') == 'crop') {
            $cropStartX = ($optimalWidth  / 2) - ($newWidth  / 2) - $offset[0];
            $cropStartY = ($optimalHeight / 2) - ($newHeight / 2) - $offset[1];
            $this->crop($cropStartX, $cropStartY, $newWidth, $newHeight);
        }

        return $this;
    }

    /**
     * Sharpen the image across a scale of 0 - 100
     * @param int $sharpness
     * @return self
     */
    public function sharpen($sharpness)
    {
        if ($sharpness <= 0 || $sharpness > 100) {
            return $this;
        }

        $image = $this->image;

        // Normalize sharpening value
        $kernelCenter = exp((80 - floatval($sharpness)) / 18) + 9;

        $matrix = array(
            [-1, -1, -1],
            [-1, $kernelCenter, -1],
            [-1, -1, -1],
        );

        $divisor = array_sum(array_map('array_sum', $matrix));

        imageconvolution($image, $matrix, $divisor, 0);

        $this->image = $image;

        return $this;
    }

    /**
     * Crops an image from its center
     * @param int $cropStartX Start on X axis
     * @param int $cropStartY Start on Y axis
     * @param int $newWidth The new width
     * @param int $newHeight The new height
     * @param int $srcWidth Source area width.
     * @param int $srcHeight Source area height.
     * @return self
     */
    public function crop($cropStartX, $cropStartY, $newWidth, $newHeight, $srcWidth = null, $srcHeight = null)
    {
        $image = $this->image;

        if ($srcWidth === null) {
            $srcWidth = $newWidth;
        }
        if ($srcHeight === null) {
            $srcHeight = $newHeight;
        }

        // Create a new canvas
        $imageResized = imagecreatetruecolor($newWidth, $newHeight);

        // Retain transparency for PNG and GIF files
        imagecolortransparent($imageResized, imagecolorallocatealpha($imageResized, 0, 0, 0, 127));
        imagealphablending($imageResized, false);
        imagesavealpha($imageResized, true);

        // Crop the  image to the requested size
        imagecopyresampled($imageResized, $image, 0, 0, $cropStartX, $cropStartY, $newWidth, $newHeight, $srcWidth, $srcHeight);

        $this->image = $imageResized;

        return $this;
    }

    /**
     * Save the image based on its file type.
     * @param string $savePath Where to save the image
     * @return boolean
     */
    public function save($savePath)
    {
        $image = $this->image;

        $imageQuality = $this->getOption('quality');

        // Determine the image type from the destination file
        $extension = FileHelper::extension($savePath) ?: $this->extension;

        // Create and save an image based on it's extension
        switch (strtolower($extension)) {
            case 'jpg':
            case 'jpeg':
                // Check JPG support is enabled
                if (imagetypes() & IMG_JPG) {
                    imagejpeg($image, $savePath, $imageQuality);
                }
                break;

            case 'gif':
                // Check GIF support is enabled
                if (imagetypes() & IMG_GIF) {
                    imagegif($image, $savePath);
                }
                break;

            case 'png':
                // Scale quality from 0-100 to 0-9
                $scaleQuality = round(($imageQuality / 100) * 9);

                // Invert quality setting as 0 is best, not 9
                $invertScaleQuality = 9 - $scaleQuality;

                // Check PNG support is enabled
                if (imagetypes() & IMG_PNG) {
                    imagepng($image, $savePath, $invertScaleQuality);
                }
                break;

            default:
                throw new Exception(sprintf('Invalid image type: %s. Accepted types: jpg, gif, png.', $extension));
                break;
        }

        // Remove the resource for the resized image
        imagedestroy($image);
    }

    /**
     * Open a file, detect its mime-type and create an image resource from it.
     * @param array $file Attributes of file from the $_FILES array
     * @return mixed
     */
    protected function openImage($file)
    {
        $mime = $file->getMimeType();
        $filePath = $file->getPathname();

        switch ($mime) {
            case 'image/jpeg': $img = @imagecreatefromjpeg($filePath); break;
            case 'image/gif':  $img = @imagecreatefromgif($filePath);  break;
            case 'image/png':  $img = @imagecreatefrompng($filePath);  break;

            default:
                throw new Exception(sprintf('Invalid mime type: %s. Accepted types: image/jpeg, image/gif, image/png.', $mime));
                break;
        }

        return $img;
    }

    /**
     * Return the image dimensions based on the option that was chosen.
     * @param int $newWidth The width of the image
     * @param int $newHeight The height of the image
     * @param string $option Either exact, portrait, landscape, auto or crop.
     * @return array
     */
    protected function getDimensions($newWidth, $newHeight)
    {
        $mode = $this->getOption('mode');

        switch ($mode) {
            case 'exact':
                return [$newWidth, $newHeight];

            case 'portrait':
                return [$this->getSizeByFixedHeight($newHeight), $newHeight];

            case 'landscape':
                return [$newWidth, $this->getSizeByFixedWidth($newWidth)];

            case 'auto':
                return $this->getSizeByAuto($newWidth, $newHeight);

            case 'crop':
                return $this->getOptimalCrop($newWidth, $newHeight);

            default:
                throw new Exception('Invalid dimension type. Accepted types: exact, portrait, landscape, auto, crop.');
        }
    }

    /**
     * Returns the width based on the image height
     * @param int $newHeight The height of the image
     * @return int
     */
    protected function getSizeByFixedHeight($newHeight)
    {
        $ratio = $this->width / $this->height;
        $newWidth = $newHeight * $ratio;

        return $newWidth;
    }

    /**
     * Returns the height based on the image width
     * @param int $newWidth The width of the image
     * @return int
     */
    protected function getSizeByFixedWidth($newWidth)
    {
        $ratio = $this->height / $this->width;
        $newHeight = $newWidth * $ratio;

        return $newHeight;
    }

    /**
     * Checks to see if an image is portrait or landscape and resizes accordingly.
     * @param int $newWidth  The width of the image
     * @param int $newHeight The height of the image
     * @return array
     */
    protected function getSizeByAuto($newWidth, $newHeight)
    {
        // Less than 1 pixel height and width? (revert to original)
        if ($newWidth <= 1 && $newHeight <= 1) {
            $newWidth = $this->width;
            $newHeight = $this->height;
        }
        elseif ($newWidth <= 1) {
            $newWidth = $this->getSizeByFixedHeight($newHeight);
        }
        // Less than 1 pixel height? (portrait)
        elseif ($newHeight <= 1) {
            $newHeight = $this->getSizeByFixedWidth($newWidth);
        }

        // Image to be resized is wider (landscape)
        if ($this->height < $this->width) {
            $optimalWidth = $newWidth;
            $optimalHeight = $this->getSizeByFixedWidth($newWidth);
        }
        // Image to be resized is taller (portrait)
        elseif ($this->height > $this->width) {
            $optimalWidth = $this->getSizeByFixedHeight($newHeight);
            $optimalHeight = $newHeight;
        }
        // Image to be resized is a square
        else {
            if ($newHeight < $newWidth) {
                $optimalWidth = $newWidth;
                $optimalHeight = $this->getSizeByFixedWidth($newWidth);
            }
            elseif ($newHeight > $newWidth) {
                $optimalWidth = $this->getSizeByFixedHeight($newHeight);
                $optimalHeight = $newHeight;
            }
            else {
                // Square being resized to a square
                $optimalWidth = $newWidth;
                $optimalHeight = $newHeight;
            }
        }

        return [$optimalWidth, $optimalHeight];
    }

    /**
     * Attempts to find the best way to crop. Whether crop is based on the
     * image being portrait or landscape.
     * @param int $newWidth  The width of the image
     * @param int $newHeight The height of the image
     * @return array
     */
    protected function getOptimalCrop($newWidth, $newHeight)
    {
        $heightRatio = $this->height / $newHeight;
        $widthRatio  = $this->width /  $newWidth;

        if ($heightRatio < $widthRatio) {
            $optimalRatio = $heightRatio;
        }
        else {
            $optimalRatio = $widthRatio;
        }

        $optimalHeight = $this->height / $optimalRatio;
        $optimalWidth  = $this->width  / $optimalRatio;

        return [$optimalWidth, $optimalHeight];
    }
}
