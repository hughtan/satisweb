<?php

class TestCase extends PHPUnit_Framework_TestCase 
{
    /**
     * Creates the application.
     *
     * @return Symfony\Component\HttpKernel\HttpKernelInterface
     */
    public function createApplication()
    {
    }

    public function testNothing()
    {
        // Test nothing
    }
}
