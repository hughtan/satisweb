<?php

namespace Illuminate\Contracts\Container;

use Illuminate\Container\BindingResolutionException as BaseException;

class BindingResolutionException extends BaseException
{
    //
}
